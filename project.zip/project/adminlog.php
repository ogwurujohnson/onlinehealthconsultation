<div class = "bootstrap-frm">
<?php
if(isset($msg) & !empty($msg)){
echo $msg;
}
?>
<link rel="stylesheet" type="text/css" href="css/stylereg.css">
<h1>Login</h1>
<form action="" method="POST">
<p><label>User Name : </label>
<input id="username" type="text" name="username" placeholder="username" /></p>
<p><label>Password&nbsp;&nbsp; : </label>
<input id="password" type="password" name="password" placeholder="password" /></p>
<a class="button" href="register.php">Signup</a>
<a class = "button" href="index.html">Home</a>
<input class="button" href="consult.php" type="submit" name="submit" value="Login" />
</form>
</div>


<?php //Start the Session
session_start();
require('connect.php');
//3. If the form is submitted or not.
//3.1 If the form is submitted
if (isset($_POST['username']) and
isset($_POST['password'])){
//3.1.1 Assigning posted values to variables.
$username = $_POST['username'];
$password = $_POST['password'];
//3.1.2 Checking the values are existing in the database or not
$query = "SELECT * FROM `admin` WHERE
username='$username' and
password='$password'";
$result = mysql_query($query) or
die(mysql_error());
$count = mysql_num_rows($result);
//3.1.2 If the posted values are equal to the database values, then session will be created for the user.
if ($count == 1){
$_SESSION['username'] = $username;
}else{
//3.1.3 If the login credentials doesn't match, he will be shown with an error message.
echo "Invalid Login Credentials.";
 }
 }
 //3.1.4 if the user is logged in redirects the user to the consultation page
if (isset($_SESSION['username'])){
$username = $_SESSION['username'];

			{
				header("Location: admin.php");
			}

 }else{
 //3.2 When the user visits the page first time, simple login form will be displayed.*/
 }
?>