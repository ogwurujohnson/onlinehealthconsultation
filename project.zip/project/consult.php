<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Consult - Consultium</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Consultium</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="logout.php">Log-Out</a></li>
						<li><a href="live.php">Chat with a practitoner</a></li>
						<!--<li><a href="">Elements</a></li>-->
					</ul>
				</nav>
			</header>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
									<form method= "POST">
									<h2>Select Symptoms you are witnessing</h2>
									
				</div>
					</header>
					</body>
					</html>
					
<form method= "POST"><input type="checkbox" name="symptom1" value="Headache" /> Headache<br/><br/>
<input type="checkbox" name="symptom2" value="Fever" /> Fever<br/><br/>
<input type="checkbox" name="symptom3" value="Heartfailure" /> Heart failure<br/><br/>
<input type="checkbox" name="symptom4" value="Fatigue" />Fatigue<br/><br/>
<input class="button" type="submit" name="submit" value="Consult" />
</form>

<?php

require('connect.php');

if (isset($_POST['symptom1']) || isset($_POST['symptom2'])|| isset($_POST['symptom3'])&& isset($_POST['symptom4'])){ 
if (isset($_POST['symptom1']) and $_POST['symptom1']!='') $symptoms[] = $_POST['symptom1'];
if (isset($_POST['symptom2']) and $_POST['symptom2']!='') $symptoms[] = $_POST['symptom2'];
if (isset($_POST['symptom3']) and $_POST['symptom3']!='') $symptoms[] = $_POST['symptom3'];
if (isset($_POST['symptom4']) and $_POST['symptom4']!='') $symptoms[] = $_POST['symptom4'];

		function evaluate ($symptoms){
			foreach($symptoms as $symptom){
					
				//convert to an array query for disease and symptom and supplied user input and match to identify disease
					$query = 'SELECT diseases FROM symptomdisease WHERE symptoms = "'.$symptom.'"';
					$result = mysql_query($query) or die(mysql_error());
					$count = mysql_num_rows($result);
					$result=mysql_fetch_assoc($result);
					$diseases[] = $result;
					}
					
			$checker ="";
			$hey=0;
				foreach ($diseases as $disease)
				{
					
					$disease = explode(",",$disease['diseases']);
					if($checker == "")
					{
						$checker = $disease;
					}
					else
					{
						$checker = array_intersect($checker, $disease);
					}
				}
					foreach ($checker as $disease){
						echo '<br>You are suffering from '.$disease.'<br>';
					
				//query for the disease drug prescription that matches the identified disease from the table disease
				$query2 = 	"SELECT drugprescription FROM disease WHERE diseases ='".$disease."'";
				$result2 = mysql_query($query2);
				$result2=mysql_fetch_assoc($result2)['drugprescription'];
				
				echo 'Take this drug "' .$result2.'".<br>';
					}
				
				}
evaluate($symptoms);
				}
				