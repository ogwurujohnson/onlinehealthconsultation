<?php
	require('connect.php');
		// If the values are posted, insert them into the database.
			if (isset($_POST['firstname']) || isset($_POST['lastname'])|| isset($_POST['username'])&& isset($_POST['password'])){
				$firstname = $_POST['firstname'];
				$lastname = $_POST['lastname'];
				$username = $_POST['username'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$query = "INSERT INTO `user` (username, password, email,firstname,lastname) VALUES ('$username', '$password', '$email','$firstname','$lastname')";
				$result = mysql_query($query);
				}
				?>
				<script src="jquery-2.0.0.min.js"></script>

<script language="javascript" type="text/javascript">  
					if($result){
						alert("User created");
						return;
					}
		</script>
					
			



<div class="bootstrap-frm">
<link rel="stylesheet" type="text/css" href="css/stylereg.css">
<script src="jquery-2.0.0.min.js"></script>

<!--<script language="javascript" type="text/javascript">-->  
	<h1>Register</h1>
		<form action="" method="POST">
		
			<p><label>Fist Name :</label>
				<input id="firstname" type="text" name="firstname" placeholder="firstname"/></p>
				
			<p><label>Last Name :</label>
				<input id="lastname" type="text" name="lastname" placeholder="lastname"/></p>
				
				
			<p><label>User Name :</label>
				<input id="username" type="text" name="username" placeholder="username"/></p>
				
			<p><label>E-mail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label>
				<input id="password" type="email" name="email"/></p>
				
			
			<p><label>Password&nbsp;&nbsp; : </label>
				<input id="password" type="password" name="password" placeholder="password" /></p>
				
	<a class="button" href="login.php">Login</a>
			<input class="button" type="submit" name="submit" value="Register" />
		</form>
</div>

