<form method= "POST">
	<h2>Select the Symptoms you're witnessing</h2>
<input type="checkbox" name="symptom1" value="Headache" /> Headache<br />
<input type="checkbox" name="symptom2" value="Fever" /> Fever<br/>
<input type="checkbox" name="symptom3" value="Heartfailure" /> Heart failure<br/>
<input type="checkbox" name="symptom4" value="Fatigue" />Fatigue
<input class="button" type="submit" name="submit" value="Consult" />
</form>

<?php

require('connect.php');

if (isset($_POST['symptom1']) || isset($_POST['symptom2'])|| isset($_POST['symptom3'])&& isset($_POST['symptom4'])){ 
if (isset($_POST['symptom1']) and $_POST['symptom1']!='') $symptoms[] = $_POST['symptom1'];
if (isset($_POST['symptom2']) and $_POST['symptom2']!='') $symptoms[] = $_POST['symptom2'];
if (isset($_POST['symptom3']) and $_POST['symptom3']!='') $symptoms[] = $_POST['symptom3'];
if (isset($_POST['symptom4']) and $_POST['symptom4']!='') $symptoms[] = $_POST['symptom4'];

		function evaluate ($symptoms){
			foreach($symptoms as $symptom){
					
				//lets trry querying for all symptoms and putting them in array and using in_array to compare the symptom array and the user array
					$query = 'SELECT diseases FROM symptomdisease WHERE symptoms = "'.$symptom.'"';
					$result = mysql_query($query) or die(mysql_error());
					$count = mysql_num_rows($result);
					$result=mysql_fetch_assoc($result);
					$diseases[] = $result;
					}
					
			$checker ="";
			$hey=0;
				foreach ($diseases as $disease)
				{
					
					$disease = explode(",",$disease['diseases']);
					if($checker == "")
					{
						$checker = $disease;
					}
					else
					{
						$checker = array_intersect($checker, $disease);
					}
				}
					foreach ($checker as $disease){
						echo 'You are suffering from '.$disease.'<br>';
					}
					
				}
evaluate($symptoms);
				}
				