<?php
if(isset($msg) & !empty($msg)){
echo $msg;
}
?>
<form action="" method = "POST">
<input type="radio" name="sex" value="male" /> Male<br />
<input type="radio" name="sex" value="boy" /> Boy<br />
<input type="radio" name="sex" value="female" /> Female
</form>
<input class="button" href="" type="submit" name="submit" value="consult" />
</form>
</div>

<?php //Start the Session
session_start();
require('connect.php');
//3. If the form is submitted or not.
//3.1 If the form is submitted
if (isset($_POST['sex'])){
//3.1.1 Assigning posted values to variables.
$gender = $_POST['sex'];
}
//3.1.2 Checking the values are existing in the database or not
$query = "SELECT * FROM `gender` WHERE gender = '$gender'";
$result = mysql_query($query) or
die(mysql_error());
$count = mysql_num_rows($result);
//3.1.2 If the posted values are equal to the database values, then session will be created for the user.
if ($count == 1){
$_SESSION['sex'] = $gender;
}
else{
//3.1.3 If the login credentials doesn't match, he will be shown with an error message.
echo "Invalid Login selection.";
 }
  
 //3.1.4 if the user is logged in redirects the user to the consultation page
if (isset($_SESSION['sex'])){
$gender = $_SESSION['sex'];

			{
				header("Location: consult.php");
			}

 }else{
 //3.2 When the user visits the page first time, simple login form will be displayed.*/
 }
?>