<?php
require('connect.php');
//this block is for adding to the first table
	if (isset($_POST['symptom']))
	{
		
	  $symptom = $_POST['symptom'];
	  
	  $query1 = "INSERT INTO `diseases` (disease) VALUES ('$symptom')";
	  $result1 = mysql_query($query1);
	}
	
	//this block is for adding to the second table
	if (isset($_POST['diseaseA']) || isset($_POST['diseaseB'])|| isset($_POST['diseaseC'])|| isset($_POST['diseaseD'])&& isset($_POST['diseaseE']))
	{ 
	  
		
		$diseaseA = $_POST['diseaseA'];
		$diseaseB = $_POST['diseaseB'];
		$diseaseC = $_POST['diseaseC'];
		$diseaseD = $_POST['diseaseD'];
		$diseaseE = $_POST['diseaseE'];
	
		
		$array = compact('diseaseA', 'diseaseB', 'diseaseC', 'diseaseD', 'diseaseE');
		
		
		$comma_separated = implode(",", $array);
		$query2 = "INSERT INTO `symptomdisease` (diseases) VALUES ('$comma_separated')";
		$result2 = mysql_query($query2);
		
		
		
		
	
	

	
	}
		
		
?>

