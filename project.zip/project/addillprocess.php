<?php
require('connect.php');
	if (isset($_POST['symptom']))
	{
		
	
	
	if (isset($_POST['diseaseA']) || isset($_POST['diseaseB'])|| isset($_POST['diseaseC'])|| isset($_POST['diseaseD'])&& isset($_POST['diseaseE']))
	{ 
	    $symptom = $_POST['symptom'];
		
		$diseaseA = $_POST['diseaseA'];
		$diseaseB = $_POST['diseaseB'];
		$diseaseC = $_POST['diseaseC'];
		$diseaseD = $_POST['diseaseD'];
		$diseaseE = $_POST['diseaseE'];
		
		
		$array = compact('diseaseA', 'diseaseB', 'diseaseC', 'diseaseD', 'diseaseE');
		
		foreach ($array as $value)
		{
		$comma_separated = implode(",", $array);
		$query = "INSERT INTO `symptomdisease` (symptoms,diseases) VALUES ('$symptom','$comma_separated')";
		
		}
		
	
	}
	$result = mysql_query($query);
	}
		
		
?>

