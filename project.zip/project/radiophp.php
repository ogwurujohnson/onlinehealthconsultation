<?php
//Error Displaying
ini_set ('display_errors',1);
error_reporting (E_ALL & ~E_NOTICE);
//Print each answer
<?php
if (isset($_POST["answer"]) && is_array($_POST["answer"])
&& count($_POST["answer"]) > 0)
{
foreach ($_POST["answer"] as $answer)
{
echo htmlspecialchars($answer, ENT_QUOTES);
echo '<br />';
}
}
?>
// Print each key and value.
<?php
$answer = array ('Never', 'Seldom', 'Occasionally', 'Often', 'Always');
foreach ($answer as $ans => $answer) {
print "$ans: $answer<br />\n";
}
?>