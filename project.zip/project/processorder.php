<?php
//create short variable names
$tireqty = $HTTP_POST_VARS['tireqty'];
$oilqty = $HTTP_POST_VARS['oilqty'];
$sparkqty = $HTTP_POST_VARS['sparkqty'];
echo $tireqty.' tires<br />';
	echo $oilqty. ' bottles of oil<br />';
	echo $sparkqty. 'spark plugs<br />';
?>
<html>
<head>
<title>Bob's Auto Parts - Order Results</title>
</head>
<body>
<h1>Bob's Auto Parts</h1>
<h2>Order Results</h2>
<?php
	echo '<p>Order processed at ';
	echo date('H:i, jS F');
	echo '</p>';
	echo '<p>Your order is as follows:</p>'
	
?>
</body>
</html>