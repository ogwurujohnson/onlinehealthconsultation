<?php
require('connect.php');
//this block is for adding to the first table
	if (isset($_POST['mktid']) && isset($_POST['mktname'])&& isset($_POST['village'])&& isset($_POST['town'])&& isset($_POST['latitude'])&& isset($_POST['longitude']))
	{
		
	  $mkt_id = $_POST['mktid'];
	  $mkt_name = $_POST['mktname'];
	  $villa = $_POST['village'];
	  $mkt_town = $_POST['town'];
	  $mkt_lat = $_POST['latitude'];
	  $mkt_long = $_POST['longitude'];
	  
	  
	  $query1 = "INSERT INTO `markets` (mktid,mktname,village,town,latitude,longitude) VALUES ('$mkt_id','$mkt_name','$villa', '$mkt_town', '$mkt_lat','$mkt_long')";
	  $result1 = mysql_query($query1);
	}
	
	//this block is for adding to the second table
	if (isset($_POST['mktid']) || isset($_POST['content']))
	{ 
	  
		
		$mkt_id = $_POST['mktid'];
		$content = $_POST['mktcon'];
		
		//$array = compact('diseaseA', 'diseaseB', 'diseaseC', 'diseaseD', 'diseaseE');
		
		
		//$comma_separated = implode(",", $array);
		$query2 = "INSERT INTO `content` (mktid,contents) VALUES ('$mkt_id','$content')";
		$result2 = mysql_query($query2);
		
		
		
		
	
	

	
	}
		
		
?>

