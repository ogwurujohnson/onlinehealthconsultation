<form name="form1" method="post" action="marketprocess.php" enctype="multipart/form-data">
<table width="80%" border="0" cellpadding="3" cellspacing="3">
<tr>
<td width="24%">market id</td>
<td width="29%"><input type="text" name="mktid" id="Name"></td>
</tr>
<tr>
<td>market name</td>
<td><input type="text" name="mktname" id="ColumnA"></td>
</tr>
<tr>
<td>village</td>
<td><input type="text" name="village" id="ColumnB"></td>
</tr>
<tr>
<td>town</td>
<td><input type="text" name="town" id="ColumnC"></td>
</tr>
<tr>
<td>market content</td>
<td><input type="text" name="mktcon" id="ColumnD"></td>
</tr>
<tr>
<td>latitude</td>
<td><input type="text" name="latitude" id="ColumnE"></td>
</tr>
<tr>
<td>longitude</td>
<td><input type="text" name="longitude" id="ColumnE"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" id="Submit" value="Save"></>
</tr>
</table>
</form>