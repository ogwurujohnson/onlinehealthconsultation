Running Server :

1. Change host address in index.php and server.php

2. Go to your shell command-line interface

3. type: 
	php -q c:\path\server.php

4. Using browser, navigate to index.php location to open chat page, have fun!


@Tutorial : http://www.sanwebe.com/2013/05/chat-using-websocket-php-socket
@License : http://opensource.org/licenses/MIT
