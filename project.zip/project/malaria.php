<form action="#" method= "POST">
	<p>It was learnt you have malaria</p><br/>
	<p> Are you having any of this symptoms</p>
<input type="checkbox" name="symptom1" value="Headache" /> Headache<br />
<input type="checkbox" name="symptom2" value="fever" /> Fever<br/>
<input type="checkbox" name="symptom3" value="fever" /> Heart failure<br/>
<input type="checkbox" name="symptom4" value="rashes" />Fatigue
</form>
<input class="button" href="consult.php" type="submit" name="submit" value="Consult" />
<?php

require('connect.php');
$symptom1 = $_POST['symptom1'];
$symptom2 = $_POST['symptom2'];
$symptom3 = $_POST['symptom3'];
$symptom4 = $_POST['symptom4'];

$symptoms= array($symptom1, $symptom2, $symptom3, $symptom4);

		function evaluate ($symptoms){
			foreach($symptoms as $symptom){
				$value++
				
					$query = "SELECT 'disease' FROM 'symptomdisease' WHERE symptoms = '$symptoms'";
					$result = mysql_query($query) or die(mysql_error());
					$count = mysql_num_rows($result);
					$diseases[$value] = $query;
					}
					
			$checker ="";
				foreach ($diseases as $disease)
				{
					if($checker == "")
					{
						$checker =$disease;
					}
					else
					{
						$checker = array_intersect($checker, $disease);
					}
				}
				
?>